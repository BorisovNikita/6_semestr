package fa.ru.ioc.demo;

public class BasketballPlayer implements SportsPlayer {
    @Override
    public void train() {
        System.out.println("I am trainig on basketball!");
    }
}
