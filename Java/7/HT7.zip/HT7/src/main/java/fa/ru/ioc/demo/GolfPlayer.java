package fa.ru.ioc.demo;

public class GolfPlayer implements SportsPlayer {
    @Override
    public void train() {
        System.out.println("I am trainig on golf!");
    }
}
