package fa.ru.ioc.demo;

public interface SportsPlayer {
    void train();
}
