package fa.ru.ioc.demo;

public class FootballPlayer implements SportsPlayer {
    @Override
    public void train() {
        System.out.println("I am trainig on football!");
    }
}
