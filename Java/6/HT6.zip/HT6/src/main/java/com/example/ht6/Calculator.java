package com.example.ht6;

public class Calculator {
    public static double add(int a, int b) {
        return a+b;
    }

    public static double div(int a, int b) {
        return a/b;
    }
    public static double mul(int a, int b) {
        return a*b;
    }
    public static double sub(int a, int b) {
        return a-b;
    }

}
