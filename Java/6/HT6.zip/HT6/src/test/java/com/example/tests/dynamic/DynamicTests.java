package com.example.tests.dynamic;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.Assert.assertTrue;

public class DynamicTests {
    @TestFactory
    Stream<DynamicTest> dynamicTests() {
        return IntStream.range(0, 5).mapToObj(
                i -> DynamicTest.dynamicTest(
                        "test "+i+"/10=0",
                        () -> assertTrue(i/10 == 0)
                )
        );
    }
}
