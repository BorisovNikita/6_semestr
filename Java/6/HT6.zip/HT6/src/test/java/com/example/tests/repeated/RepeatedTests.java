package com.example.tests.repeated;

import com.example.ht6.Calculator;
import org.junit.jupiter.api.*;

public class RepeatedTests {

    @DisplayName("Repeated")
    @RepeatedTest(value = 10, name = "{displayName} >>> repetition {currentRepetition} of {totalRepetitions}")
    void sub() {
        double result = Calculator.sub(2, 3);
        double predict = (int) (Math.random() * (3)) - 1;
        Assertions.assertEquals(predict, result, "2-3 should equals -1");
    }

}
