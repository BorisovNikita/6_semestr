import java.lang.annotation.Annotation;
import java.lang.reflect.*;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InvocationTargetException, InstantiationException {

        Class clazz = ExampleClass.class;

//        point 1
        System.out.println("Parameters:");
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            StringBuilder string = new StringBuilder();
            string.append("--------\nParameter name: ");
            string.append(field.getName());
            string.append("\nType: ");
            string.append(field.getType());
            string.append("\nModifiers: ");
            string.append(Modifier.toString(field.getModifiers()));
            System.out.println(string);
        }

//        Point 2
        Method[] methods = clazz.getDeclaredMethods();
        System.out.println("\nMethods:");
        for (Method method : methods) {
            System.out.println("--- " + method.getName());
        }

//        Point 3
        Constructor[] constructors = clazz.getConstructors();
        System.out.println("\nConstructors: ");
        for (Constructor constructor : constructors) {
            System.out.println("--- " + constructor.toString());
        }

//        Point 4
        System.out.println("\nParameters values:");
        ExampleClass exampleClass = new ExampleClass(); //Point 6
        for (Field field : fields) {
            field.setAccessible(true);
            System.out.println("--- " + field.getName() + ": " + field.get(exampleClass));
        }

//        Point 5
        System.out.println("\nAnnotations:");
        for (Method method : methods) {
            Annotation[] annotations = method.getDeclaredAnnotations();
            if (annotations.length!=0) {
                System.out.println("Method " + method.getName());
            }
            for (Annotation annotation : annotations) {
                System.out.println("--- " + annotation.toString());
            }
        }

//        Point 6
        ExampleClass exampleClass1 = (ExampleClass) clazz.getConstructors()[0].newInstance();


    }



}
