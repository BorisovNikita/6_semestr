package com.example.tests;
import org.junit.platform.suite.api.*;



@SelectPackages({"com.example.tests"})
@ExcludePackages("com.example.tests.testB")
@IncludeTags("DEV")
@Suite
public class SuiteExample {
}
