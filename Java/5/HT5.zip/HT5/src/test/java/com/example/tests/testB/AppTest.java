package com.example.tests.testB;

import com.example.ht5.Calculator;
import com.example.ht5.ExampleClass;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.time.Duration;
import java.util.*;

public class AppTest {
    public static String str = "Hello World!";
    public static String str2 = "Hello World?";

    @Test
    @Tag("DEV")
    void arrayTest(){

        Assertions.assertArrayEquals(str2.toCharArray(), ExampleClass.getChars(str));
    }

    @Test
    void iterableTest() {
        TreeSet set = new TreeSet();
        for (char ch : str2.toCharArray()) {
            set.add(ch);
        }
        Assertions.assertIterableEquals(set, ExampleClass.getIterable(str));
    }

    @Test
    void linesMatchTest() {
        List lst1 = List.of(new String[]{str, str2, str2});
        List lst2 = List.of(new String[]{str, str2, str});

        Assertions.assertLinesMatch(lst1, lst2);
    }

    @Test
    void notNullTest(){
        String str2 = null;
        Assertions.assertNotNull(str2);
    }

    @Test
    void sameTest(){
        String str2 = str.repeat(1000);
        String str3 = str.repeat(1000);
        Assertions.assertSame(str3, str2);
    }

    @Test
    void timeoutTest() {
        Executable executable = () -> ExampleClass.doTimeout(1000);
        Duration duration = Duration.ofSeconds(1);
        Assertions.assertTimeout(duration, executable);
    }

    @Test
    void throwsTest() {
        Assumptions.assumeFalse(Calculator.add(10,5) == 15);
        Assertions.assertThrows(ArithmeticException.class, () -> Calculator.div(10,0));
    }


}
