package com.example.tests.testA;

import org.junit.jupiter.api.*;
import com.example.ht5.Calculator;

public class AppTest {
    @BeforeAll
    static void setup(){
        System.out.println("We will start our tests (@BeforeAll)");
    }

    @AfterAll
    static void tear(){
        System.out.println("It's the end of the tests (@AfterAll)");
    }

    @BeforeEach
    void setupThis(){
        System.out.println("Next step starts (@BeforeEach)");
    }

    @AfterEach
    void tearThis(){
        System.out.println("Current step finished (@AfterEach)");
    }

    @Tag("DEV")
    @Test
    @DisplayName("addition")
    void testCalcOne()
    {
        System.out.println("======TEST ADDITION=======");
        Assertions.assertEquals( 4 , Calculator.add(2, 2));
    }

    @Tag("DEV")
    @Test
    @DisplayName("multiplication")
    void testCalcTwo()
    {
        System.out.println("======TEST MULTIPLICATION=======");
        Assertions.assertEquals( 4 , Calculator.mul(2, 2));
    }

    @Tag("PROD")
    @Test
    @Disabled
    @DisplayName("subtraction")
    void testCalcThird()
    {
        System.out.println("======TEST SUBTRACTION=======");
        Assertions.assertEquals( 3 , Calculator.sub(6, 3));
    }



}
