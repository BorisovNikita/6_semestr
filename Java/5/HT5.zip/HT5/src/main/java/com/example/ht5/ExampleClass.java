package com.example.ht5;

import java.util.Iterator;
import java.util.TreeSet;

public class ExampleClass {


    public static char[] getChars(String string) {
        return string.toCharArray();
    }

    public static Iterable getIterable(String string) {

        TreeSet set = new TreeSet();
        for (char ch : string.toCharArray()) {
            set.add(ch);
        }
        return set;
    }

    public static void doTimeout(int timeout) throws InterruptedException {
        Thread.sleep(timeout);

    }
}
