package fa.ru.demo.code;

public interface SportsPlayer {

    void train();
    void print();
}
