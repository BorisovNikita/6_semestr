package fa.ru.demo.xml;

public interface SportsPlayer {

    void train();
    void print();
}
