package fa.ru.demo.mix;

public interface SportsPlayer {

    void train();
    void print();
}
