package fa.ru.demo.code;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


public class Config {
    @Bean
    FootballPlayer benzima() {
        SportsTeam sportsTeam = new SportsTeam();
        sportsTeam.setName("It's new team for Benzima");
        FootballPlayer player = new FootballPlayer(sportsTeam);
        player.setName("Benzima");
        player.setSalary(100000);
        player.setPosition("Defender");
        return player;
    }
}
