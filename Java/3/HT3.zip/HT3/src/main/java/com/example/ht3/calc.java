package com.example.ht3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;


/**
 * It's main class with start method. To start program you must run main()
 @author Borisov and Temiraeva
 */
public class calc extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        /**
         * This is a root (or parent) loader from fxml file
         */
        FXMLLoader loader = new FXMLLoader();
        URL xmlUrl = getClass().getResource("auth.fxml");
        loader.setLocation(xmlUrl);
        Parent root = loader.load();

        /**
         * Initialise the first scene (authentication)
         */
        Scene scene = new Scene(root);

//        String stylesheet = getClass().getResource("styles.css").toExternalForm();
//        scene.getStylesheets().add(stylesheet);

        stage.setScene(scene);
        stage.setMinHeight(200);
        stage.setMinWidth(200);
        stage.setTitle("Authentication");
        stage.show();

    }

    /**
     * Entry point of programm
     */
    public static void main(String[] args) {
        launch();
    }
}
