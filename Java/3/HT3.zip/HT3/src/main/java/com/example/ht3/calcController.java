package com.example.ht3;



import com.fathzer.soft.javaluator.DoubleEvaluator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class calcController {

    /**
     * Main textField param
     */
    @FXML
    private TextField textField;

//    private Stage stage;


    /**
     * Action for signs and numbers (0-9, -, /, *, +, ., (, ) )
     * @param actionEvent the event of clickButton action, to take text from target Button
     */
    @FXML
    private void clickButton(ActionEvent actionEvent) {

        Button button = (Button) actionEvent.getTarget();
        textField.appendText(button.getText());

//        stage.setScene();
    }

    /**
     * Action for backspace button
     */
    @FXML
    private void clickBackspace() {
        int length = textField.getText().length();
        if (length!=0) {
            textField.deleteText(length-1, length);
        }
    }


    /**
     * Action for "=" button to calculate expression
     */
    @FXML
    private void toCompute() {
        String expression = textField.getText();
        DoubleEvaluator eval  = new DoubleEvaluator();
        Double result = eval.evaluate(expression);

        /**
         * if the remainder of the division is very small, then round to the integer
         */
        if (Math.abs(result -  Math.round(result)) < 0.0000000000000000000000001) {
            textField.setText(Integer.toString(result.intValue()));
        } else {
            textField.setText(result.toString());
        }

    }
}
