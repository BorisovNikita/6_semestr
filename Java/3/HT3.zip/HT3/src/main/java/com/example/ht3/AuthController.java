package com.example.ht3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class AuthController {

    @FXML
    private Button btnLogin;

    @FXML
    private PasswordField password;

    @FXML
    private TextField login;

    /**
     * Action method for LogIn button (check login and password)
     */
    @FXML
    private void onLoginClick() throws IOException {
        if (!(login.getText().equals("temir") && (password.getText().equals("bo")))) {
            return;
        }

        Stage stage;
        Parent root;
        stage = (Stage) btnLogin.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("calc.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("MyCalculator");
        stage.setMinHeight(300);
        stage.setMinWidth(200);
        stage.show();




    }
}
