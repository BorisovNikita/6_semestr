module com.example.ht3 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.ht3 to javafx.fxml;
    exports com.example.ht3;

    requires javaluator;
    requires exp4j;

}